#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void drop_n_left(char *s, int n)
{
    if(strlen(s)>1)
    {
        char* s2 = s + n;
        while ( *s2 )
        {
            *s = *s2;
            ++s;
            ++s2;
        }
        *s = '\0';
    }
}



int main()
{

    /* Apertura del fichero*/
    FILE *entrada, *salida;
    entrada = fopen("C:\\Users\\hugoj\\Downloads\\dns.txt","r");
    if(entrada == NULL)
    {
        printf("Error en la apertura del fichero de entrada");
        exit(1);
    }

    salida  = fopen(".\\dns.txt","a");
    if(salida == NULL)
    {
        fclose(entrada);
        printf("Error en la apertura del fichero de salida");
        exit(2);
    }

    char linea[500];
    char lineaAnterior[500];


    /* Lectura y tratamiento del fichero */
    while(fgets(linea, 500, entrada))
    {
        drop_n_left(linea, 4);
        if(linea[0]=='-')
        {
            printf("%s", lineaAnterior);
            fputs(lineaAnterior, salida);
        }
        strcpy(lineaAnterior, linea);
    }

    fclose(entrada);
    fclose(salida);

    return 0;
}

